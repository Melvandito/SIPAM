/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.pdam.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Melvandito
 */
@Entity
@Table(name = "pembayaran")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pembayaran.findAll", query = "SELECT p FROM Pembayaran p"),
    @NamedQuery(name = "Pembayaran.findByIdPembayaran", query = "SELECT p FROM Pembayaran p WHERE p.idPembayaran = :idPembayaran"),
    @NamedQuery(name = "Pembayaran.findByNoVirtual", query = "SELECT p FROM Pembayaran p WHERE p.noVirtual = :noVirtual"),
    @NamedQuery(name = "Pembayaran.findByNamaUser", query = "SELECT p FROM Pembayaran p WHERE p.namaUser = :namaUser"),
    @NamedQuery(name = "Pembayaran.findByNamaAkunBank", query = "SELECT p FROM Pembayaran p WHERE p.namaAkunBank = :namaAkunBank"),
    @NamedQuery(name = "Pembayaran.findByNamaBank", query = "SELECT p FROM Pembayaran p WHERE p.namaBank = :namaBank"),
    @NamedQuery(name = "Pembayaran.findByTanggalTransfer", query = "SELECT p FROM Pembayaran p WHERE p.tanggalTransfer = :tanggalTransfer"),
    @NamedQuery(name = "Pembayaran.findByRegional", query = "SELECT p FROM Pembayaran p WHERE p.regional = :regional"),
    @NamedQuery(name = "Pembayaran.findByJumlah", query = "SELECT p FROM Pembayaran p WHERE p.jumlah = :jumlah"),
    @NamedQuery(name = "Pembayaran.findByIdPelanggan", query = "SELECT p FROM Pembayaran p WHERE p.idPelanggan = :idPelanggan"),
    @NamedQuery(name = "Pembayaran.findByStatus", query = "SELECT p FROM Pembayaran p WHERE p.status = :status")})
public class Pembayaran implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_pembayaran")
    private Integer idPembayaran;
    @Basic(optional = false)
    @Column(name = "no_virtual")
    private int noVirtual;
    @Basic(optional = false)
    @Column(name = "nama_user")
    private String namaUser;
    @Basic(optional = false)
    @Column(name = "nama_akun_bank")
    private String namaAkunBank;
    @Basic(optional = false)
    @Column(name = "nama_bank")
    private String namaBank;
    @Basic(optional = false)
    @Column(name = "tanggal_transfer")
    private String tanggalTransfer;
    @Basic(optional = false)
    @Column(name = "regional")
    private int regional;
    @Basic(optional = false)
    @Column(name = "jumlah")
    private int jumlah;
    @Basic(optional = false)
    @Column(name = "id_pelanggan")
    private int idPelanggan;
    @Basic(optional = false)
    @Column(name = "status")
    private int status;

    public Pembayaran() {
    }

    public Pembayaran(Integer idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public Pembayaran(Integer idPembayaran, int noVirtual, String namaUser, String namaAkunBank, String namaBank, String tanggalTransfer, int regional, int jumlah, int idPelanggan, int status) {
        this.idPembayaran = idPembayaran;
        this.noVirtual = noVirtual;
        this.namaUser = namaUser;
        this.namaAkunBank = namaAkunBank;
        this.namaBank = namaBank;
        this.tanggalTransfer = tanggalTransfer;
        this.regional = regional;
        this.jumlah = jumlah;
        this.idPelanggan = idPelanggan;
        this.status = status;
    }

    public Pembayaran(int noVirtual, String namaUser, String namaAkunBank, String namaBank, String tanggalTransfer, int regional, int jumlah, int idPelanggan, int status) {
        this.noVirtual = noVirtual;
        this.namaUser = namaUser;
        this.namaAkunBank = namaAkunBank;
        this.namaBank = namaBank;
        this.tanggalTransfer = tanggalTransfer;
        this.regional = regional;
        this.jumlah = jumlah;
        this.idPelanggan = idPelanggan;
        this.status = status;
    }

    
    public Integer getIdPembayaran() {
        return idPembayaran;
    }

    public void setIdPembayaran(Integer idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public int getNoVirtual() {
        return noVirtual;   
    }

    public void setNoVirtual(int noVirtual) {
        this.noVirtual = noVirtual;
    }

    public String getNamaUser() {
        return namaUser;
    }

    public void setNamaUser(String namaUser) {
        this.namaUser = namaUser;
    }

    public String getNamaAkunBank() {
        return namaAkunBank;
    }

    public void setNamaAkunBank(String namaAkunBank) {
        this.namaAkunBank = namaAkunBank;
    }

    public String getNamaBank() {
        return namaBank;
    }

    public void setNamaBank(String namaBank) {
        this.namaBank = namaBank;
    }

    public String getTanggalTransfer() {
        return tanggalTransfer;
    }

    public void setTanggalTransfer(String tanggalTransfer) {
        this.tanggalTransfer = tanggalTransfer;
    }

    public int getRegional() {
        return regional;
    }

    public void setRegional(int regional) {
        this.regional = regional;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public int getIdPelanggan() {
        return idPelanggan;
    }

    public void setIdPelanggan(int idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idPembayaran != null ? idPembayaran.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pembayaran)) {
            return false;
        }
        Pembayaran other = (Pembayaran) object;
        if ((this.idPembayaran == null && other.idPembayaran != null) || (this.idPembayaran != null && !this.idPembayaran.equals(other.idPembayaran))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.pdam.model.Pembayaran[ idPembayaran=" + idPembayaran + " ]";
    }
    
}
