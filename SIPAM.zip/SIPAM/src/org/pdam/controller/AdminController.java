package org.pdam.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.JabatanDao;
import org.pdam.dao.PegawaiDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.dao.impl.JabatanDaoImplHibernate;
import org.pdam.dao.impl.PegawaiDaoImplHibernate;
import org.pdam.dao.impl.PelangganDaoImplHibernate;
import org.pdam.model.Akun;
import org.pdam.model.Jabatan;
import org.pdam.model.Pegawai;
import org.pdam.model.Pelanggan;

public class AdminController 
{

    @FXML
    private TextField namapegawaiTF;

    @FXML
    private TextField passwordPegawaiTF;

    @FXML
    private TextField tahunMasukTF;

    @FXML
    private TextField NomorteleponpegawaiTF;

    @FXML
    private TextField AlamatpegawaiTF;

    @FXML
    private TextField userPegawaiTF;

    @FXML
    private TextField idregionalpegawaiTF;

    @FXML
    private TextField jabatanTF;

    @FXML
    private TextField namapelangganTF;

    @FXML
    private TextField nomorVirtualTF;

    @FXML
    private TextField pekerjaanTF;

    @FXML
    private TextField alamatpelangganTF;

    @FXML
    private TextField nomorteleponpelangganTF;

    @FXML
    private TextField idRegionalPelangganTF;

    @FXML
    private TextField usernamePelangganTF;

    @FXML
    private TextField passwordPelangganTF;

    @FXML
    private TextField IdPegawaiTF;
    
    @FXML
    private TextField tagihanTF;

    @FXML
    private Label invalidPegawaiLB;

    @FXML
    private Label IDPegLB;

    @FXML
    private Label UsernamePegLB;

    @FXML
    private Label NamaPegLB;

    @FXML
    private Label AlamatPegLB;

    @FXML
    private Label NoTelpPegLB;

    @FXML
    private Label IdRegionalPegLB;

    @FXML
    private Label MasukPegLB;

    @FXML
    private Label jabatanLB;

    @FXML
    private TextField IDPelTF;

    @FXML
    private Label IDPlgLB;

    @FXML
    private Label idRegPelLB;
    
    @FXML
    private Label UsernamePlgLB;

    @FXML
    private Label NamaPlgLB;

    @FXML
    private Label AlamatPlgLB;

    @FXML
    private Label PekerjaanPlgLB;

    @FXML
    private Label TagihanPlgLB;

    @FXML
    private Label NoTelpPlgLB;

    @FXML
    private Label NoVirPlgLB;

    @FXML
    private Label errorPegLB;
    
    @FXML
    private Label errorPelLB;
    
    @FXML
    private Label berhasilPegLB;
    
    @FXML
    private Label berhasilPelLB;
    
    private AkunDao aDao;
    private PelangganDao pelDao;
    private PegawaiDao pegDao;
    private JabatanDao jDao;

    
    public AdminController() 
    {
        aDao = new AkunDaoImplHibernate();
        pelDao = new PelangganDaoImplHibernate();
        pegDao = new PegawaiDaoImplHibernate();
        jDao = new JabatanDaoImplHibernate();
    }
    
    @FXML
    void logoutBT(ActionEvent event) throws IOException
    {
        Akun a = aDao.getAkunAktif();
        System.out.println("awal "+a.getId());
        a.setId(0);
        aDao.updateIDAkun(a);
        System.out.println("akhir "+a.getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent, 608, 228);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void addPegawaiBT(ActionEvent event) 
    {
        String nama = namapegawaiTF.getText();
        String alamat = AlamatpegawaiTF.getText();
        String username = userPegawaiTF.getText();
        String password = passwordPegawaiTF.getText();
        
        
        if(nama.isEmpty() || alamat.isEmpty() || username.isEmpty() || password.isEmpty() || tahunMasukTF.getText().trim().isEmpty() || NomorteleponpegawaiTF.getText().trim().isEmpty() || idregionalpegawaiTF.getText().trim().isEmpty() || jabatanTF.getText().trim().isEmpty())
        {
            errorPegLB.setVisible(true);
        }
        else
        {
            errorPegLB.setVisible(false);
            int tahunMasuk = Integer.parseInt(tahunMasukTF.getText());
            int noTelepon = Integer.parseInt(NomorteleponpegawaiTF.getText());
            int idRegional = Integer.parseInt(idregionalpegawaiTF.getText());
            int idJabatan = Integer.parseInt(jabatanTF.getText());
            Pegawai pegawai = new Pegawai(username, password, nama, alamat, noTelepon, idRegional, tahunMasuk, idJabatan);
            pegDao.savePegawai(pegawai);
            inisialisasiInputan();
            berhasilPegLB.setVisible(true);
        }
        
    }

    @FXML
    void addPelangganBT(ActionEvent event)
    {
        String nama = namapelangganTF.getText();
        String alamat = alamatpelangganTF.getText();
        String username = usernamePelangganTF.getText();
        String password = passwordPelangganTF.getText();
        String pekerjaan = pekerjaanTF.getText();
        
        if(nama.isEmpty() ||alamat.isEmpty() || username.isEmpty() || nomorVirtualTF.getText().trim().isEmpty() || pekerjaan.isEmpty() || password.isEmpty() || tagihanTF.getText().trim().isEmpty() || nomorteleponpelangganTF.getText().trim().isEmpty() || idRegionalPelangganTF.getText().trim().isEmpty())
        {
            errorPelLB.setVisible(true);
        }
        else
        {
            errorPelLB.setVisible(false);
            int tagihan = Integer.parseInt(tagihanTF.getText());
            int noVirtual = Integer.parseInt(nomorVirtualTF.getText());
            int noTelepon = Integer.parseInt(nomorteleponpelangganTF.getText());
            int idRegional = Integer.parseInt(idRegionalPelangganTF.getText());
            Pelanggan pelanggan = new Pelanggan(username, nama, alamat, pekerjaan, tagihan, idRegional, noTelepon, password, noVirtual);
            pelDao.savePelanggan(pelanggan);
            inisialisasiInputan();
            berhasilPelLB.setVisible(true);
        }
    }

    @FXML
    void CariPelangganBT(ActionEvent event) 
    {
        int idPel = Integer.parseInt(IDPelTF.getText());
        Pelanggan p = pelDao.getPelangganByIDPelanggan(idPel);
        
        IDPlgLB.setText(Integer.toString(idPel));
        UsernamePlgLB.setText(p.getUsername());
        NamaPlgLB.setText(p.getNamaPelanggan());
        AlamatPlgLB.setText(p.getAlamat());
        PekerjaanPlgLB.setText(p.getPekerjaan());
        TagihanPlgLB.setText(Integer.toString(p.getTagihan()));
        idRegPelLB.setText(Integer.toString(p.getIdRegional()));
        NoTelpPlgLB.setText(Integer.toString(p.getNoTelepon()));
        NoVirPlgLB.setText(Integer.toString(p.getNoVirtual()));
        inisialisasiInputan();
    }
    
    @FXML
    void cariPegawaiBT(ActionEvent event) 
    {
        int idPeg = Integer.parseInt(IdPegawaiTF.getText());
        Pegawai p = pegDao.getPegawaiByID(idPeg);
        
        IDPegLB.setText(Integer.toString(idPeg));
        UsernamePegLB.setText(p.getUsername());
        NamaPegLB.setText(p.getNamaPegawai());
        AlamatPegLB.setText(p.getAlamat());
        NoTelpPegLB.setText(Integer.toString(p.getNoTelepon()));
        IdRegionalPegLB.setText(Integer.toString(p.getIdRegional()));
        MasukPegLB.setText(Integer.toString(p.getTahunMasuk()));
        jabatanLB.setText(jDao.getJabatanByID(p.getIdJabatan()).getNama());
        inisialisasiInputan();
    }

    private void inisialisasiInputan()
    {
        namapegawaiTF.setText("");
        AlamatpegawaiTF.setText("");
        userPegawaiTF.setText("");
        passwordPegawaiTF.setText("");
        tahunMasukTF.setText("");
        NomorteleponpegawaiTF.setText("");
        idregionalpegawaiTF.setText("");
        jabatanTF.setText("");
        
        namapelangganTF.setText("");
        alamatpelangganTF.setText("");
        usernamePelangganTF.setText("");
        passwordPelangganTF.setText("");
        pekerjaanTF.setText("");
        tagihanTF.setText("");
        nomorVirtualTF.setText("");
        nomorteleponpelangganTF.setText("");
        idRegionalPelangganTF.setText("");
        
        IDPelTF.setText("");
        IdPegawaiTF.setText("");
    }
}
