package org.pdam.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.pdam.dao.AkunDao;
import org.pdam.dao.PegawaiDao;
import org.pdam.dao.PelangganDao;
import org.pdam.dao.PembayaranDao;
import org.pdam.dao.impl.AkunDaoImplHibernate;
import org.pdam.dao.impl.PegawaiDaoImplHibernate;
import org.pdam.dao.impl.PelangganDaoImplHibernate;
import org.pdam.dao.impl.PembayaranDaoImplHibernate;
import org.pdam.model.Akun;
import org.pdam.model.Pegawai;
import org.pdam.model.Pembayaran;

public class VerifikasiController implements Initializable
{

    @FXML
    private TextField IDTF;

    @FXML
    private TableView<Pembayaran> pembayaranTV;

    @FXML
    private TableColumn<Pembayaran,Integer> IdTC;

    @FXML
    private TableColumn<Pembayaran,String> NamaTC;

    @FXML
    private TableColumn<Pembayaran,String> NamaAkunTC;
    
    @FXML
    private TableColumn<Pembayaran,String> BankTC;

    @FXML
    private TableColumn<Pembayaran,String> TanggalTC;

    @FXML
    private TableColumn<Pembayaran,Integer> JumlahTC;

    @FXML
    private Label akunLB;

    @FXML
    private Label invalidLB;
    
    private PembayaranDao pemDao;
    private PelangganDao pelDao;
    private AkunDao aDao;
    private PegawaiDao pegDao;
    
    ObservableList<Pembayaran> data;

    public VerifikasiController() 
    {
        aDao = new AkunDaoImplHibernate();
        pemDao = new PembayaranDaoImplHibernate();
        pembayaranTV = new TableView<>();
        pelDao = new PelangganDaoImplHibernate();
        pegDao = new PegawaiDaoImplHibernate();
    }
    
    @FXML
    void tentangAkun(ActionEvent event) throws IOException
    {
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/AkunPegawai.fxml"));
        Scene scene = new Scene(parent,600,500);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    void logoutBT(ActionEvent event) throws IOException 
    {
        Akun a = aDao.getAkunAktif();
        System.out.println("awal "+a.getId());
        a.setId(0);
        aDao.updateIDAkun(a);
        System.out.println("akhir "+a.getId());
        ((Node)(event.getSource())).getScene().getWindow().hide();
        Stage stage = new Stage();
        Parent parent = FXMLLoader.load(getClass().getResource("/org/pdam/view/Login.fxml"));
        Scene scene = new Scene(parent, 608, 228);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void verifikasiBT(ActionEvent event) 
    {
        int id = Integer.parseInt(IDTF.getText());
        Pegawai pegAktif = pegDao.getPegawaiByUsername(aDao.getAkunAktif().getUsername());
        List<Pembayaran> pembayarans = pemDao.getAllBelumVerifikasiByRegional(pegAktif.getIdRegional());
        Pembayaran pem = null;
        boolean status = false;
        for(Pembayaran p : pembayarans)
        {
            if(p.getIdPembayaran()==id)
            {
                pem = p;
                status = true;
            }
        }
        if(status)
        {
            invalidLB.setVisible(false);
            pem.setStatus(1);
            pemDao.updateStatusPembayaran(pem);
            IDTF.setText("");
            loadData();
        }
        else
        {
            invalidLB.setVisible(true);
        }
        
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) 
    {
        loadData();
    }

    public void loadData()
    {
        Pegawai pegAktif = pegDao.getPegawaiByUsername(aDao.getAkunAktif().getUsername());
        List<Pembayaran> pembayarans = pemDao.getAllBelumVerifikasiByRegional(pegAktif.getIdRegional());
        data = FXCollections.observableArrayList(pembayarans);
        IdTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,Integer>("idPembayaran"));
        NamaTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("namaUser"));
        NamaAkunTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("namaAkunBank"));
        BankTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("namaBank"));
        TanggalTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,String>("tanggalTransfer"));
        JumlahTC.setCellValueFactory(new PropertyValueFactory<Pembayaran,Integer>("jumlah"));
        
        pembayaranTV.setItems(data);
        
        akunLB.setText(aDao.getAkunAktif().getUsername());
    }
}
