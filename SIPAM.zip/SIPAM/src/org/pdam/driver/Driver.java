package org.pdam.driver;

import static javafx.application.Application.launch;

/**
 *
 * @author Melvandito
 */
public class Driver 
{
    public static void main(String[] args)
    {
        launch(PDAM.class,args);
        
    }
}
