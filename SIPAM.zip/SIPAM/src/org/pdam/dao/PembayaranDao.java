package org.pdam.dao;

import java.util.List;
import org.pdam.model.Pelanggan;
import org.pdam.model.Pembayaran;

/**
 *
 * @author Melvandito
 */
public interface PembayaranDao 
{
    public void savePembayaran(Pembayaran pembayaran);
    public List<Pembayaran> getAllBelumVerfikasi(int idPelanggan);
    public List<Pembayaran> getAllSudahVerfikasi(int idPelanggan);
    public Pembayaran getPembayaranByID(int idPembayaran);
    public List<Pembayaran> getAllBelumVerifikasiByRegional(int idRegional);
    public void updateStatusPembayaran(Pembayaran pembayaran);
}
