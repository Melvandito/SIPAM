package org.pdam.dao.impl;

import org.hibernate.Session;
import org.pdam.dao.RegionalDao;
import org.pdam.model.Regional;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class RegionalDaoImplHibernate implements RegionalDao
{

    @Override
    public void saveRegional(Regional regional) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(regional);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public void getAllAnggotaRegionalByID(int idRegional) 
    {
        
    }
    
    
}
