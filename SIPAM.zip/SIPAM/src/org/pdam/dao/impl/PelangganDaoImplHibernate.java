package org.pdam.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.pdam.dao.PelangganDao;
import org.pdam.model.Akun;
import org.pdam.model.Pelanggan;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class PelangganDaoImplHibernate implements PelangganDao
{
    @Override
    public List<Pelanggan> getPelangganByIDRegional(int idRegional) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pelanggan> pelanggans = session.createCriteria(Pelanggan.class).list();
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return pelanggans;
    }

    @Override
    public void savePelanggan(Pelanggan pelanggan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pelanggan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public String cekAkunPelanggan(String username, String password) 
    {
        String status = "str";
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pelanggan> pelanggans = getAllPelanggan();
        for (Pelanggan pelanggan : pelanggans) 
        {
            if (pelanggan.getUsername().equalsIgnoreCase(username) && pelanggan.getPassword().equalsIgnoreCase(password))
            {
                status = "pelanggan";
                break;
            }
        }
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return status;
    }

    @Override
    public List<Pelanggan> getAllPelanggan() 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pelanggan> pelanggans = session.createCriteria(Pelanggan.class).list();
        session.getTransaction().commit();
        return pelanggans;
    }

    @Override
    public Pelanggan getPelangganByUsername(String username) 
    {
        List<Pelanggan> pelanggans = getAllPelanggan();
        Pelanggan pelanggan = null;
        for(Pelanggan p : pelanggans)
        {
            if(p.getUsername().equalsIgnoreCase(username))
            {
                pelanggan = (Pelanggan)p;
            }
        }
        return pelanggan;
    }
    
    @Override
    public void updatePasswordAkun(Pelanggan pelanggan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin(); 
        session.update("password",pelanggan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Pelanggan getPelangganByIDPelanggan(int idPelanggan) 
    {
        List<Pelanggan> pelanggans = getAllPelanggan();
        Pelanggan pelanggan = null;
        for(Pelanggan p : pelanggans)
        {
            if(p.getIdPelanggan()==idPelanggan)
            {
                pelanggan = p;
            }
        }
        return pelanggan;
    }
    
}
