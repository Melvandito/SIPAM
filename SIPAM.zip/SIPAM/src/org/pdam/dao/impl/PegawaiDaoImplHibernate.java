package org.pdam.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.pdam.dao.PegawaiDao;
import org.pdam.model.Pegawai;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class PegawaiDaoImplHibernate implements PegawaiDao
{

    @Override
    public void savePegawai(Pegawai pegawai) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(pegawai);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Pegawai getPegawaiByID(int idPegawai)
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Pegawai p = (Pegawai)session.get(Pegawai.class,idPegawai);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return p;
    }

    @Override
    public String cekAkunPegawai(String username, String password) 
    {
        String status = "str";
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pegawai> pegawais = getAllPegawai();
        for (Pegawai pegawai : pegawais) 
        {
            if (pegawai.getUsername().equalsIgnoreCase(username) && pegawai.getPassword().equalsIgnoreCase(password))
            {
                status = "pegawai";
                break;
            }
        }
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return status;
    }

    @Override
    public List<Pegawai> getAllPegawai()
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Pegawai> pegawais = session.createCriteria(Pegawai.class).list();
        session.getTransaction().commit();
        return pegawais;
    }

    @Override
    public Pegawai getPegawaiByUsername(String username)
    {
        List<Pegawai> pegawais = getAllPegawai();
        Pegawai peg  = null;
        for(Pegawai p : pegawais)
        {
            if(p.getUsername().equalsIgnoreCase(username))
            {
                peg = (Pegawai)p;
            }
        }
        return peg;
    }
    
    @Override
    public void updatePasswordAkun(Pegawai pegawai)
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin(); 
        session.update("password",pegawai);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }
    
}
