package org.pdam.dao.impl;

import java.util.List;
import org.hibernate.Session;
import org.pdam.dao.JabatanDao;
import org.pdam.model.Jabatan;
import org.pdam.util.HibernateUtil;

/**
 *
 * @author Melvandito
 */
public class JabatanDaoImplHibernate implements JabatanDao
{

    @Override
    public void saveJabatan(Jabatan jabatan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        session.save(jabatan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
    }

    @Override
    public Jabatan getJabatanByID(int idJabatan) 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        Jabatan j = (Jabatan)session.get(Jabatan.class,idJabatan);
        session.getTransaction().commit();
        HibernateUtil.closeSession();
        return j;
    }

    @Override
    public List<Jabatan> getAllJabatan() 
    {
        Session session = HibernateUtil.getSession();
        session.getTransaction().begin();
        List<Jabatan> jabatans = session.createCriteria(Jabatan.class).list();
        session.getTransaction().commit();
        return jabatans;
    }

    @Override
    public Jabatan getJabatanByNama(String nama)
    {
        List<Jabatan> jabatans = getAllJabatan();
        Jabatan jab = null;
        for(Jabatan j : jabatans)
        {
            if(j.getNama().equalsIgnoreCase(nama))
            {
                jab = j;
            }
        }
        return jab;
    }

}
