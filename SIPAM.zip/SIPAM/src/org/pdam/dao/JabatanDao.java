package org.pdam.dao;

import java.util.List;
import org.pdam.model.Jabatan;

/**
 *
 * @author Melvandito
 */
public interface JabatanDao 
{
    public void saveJabatan(Jabatan jabatan);
    public Jabatan getJabatanByID(int idJabatan);
    public List<Jabatan> getAllJabatan();
    public Jabatan getJabatanByNama(String nama);
}
