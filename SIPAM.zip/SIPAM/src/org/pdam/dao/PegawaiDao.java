package org.pdam.dao;

import java.util.List;
import org.pdam.model.Akun;
import org.pdam.model.Pegawai;
import org.pdam.model.Pelanggan;

/**
 *
 * @author Melvandito
 */
public interface PegawaiDao 
{
    public void savePegawai(Pegawai pegawai);
    public Pegawai getPegawaiByID(int idPegawai);
    public String cekAkunPegawai(String username,String password);
    public List<Pegawai> getAllPegawai();
    public Pegawai getPegawaiByUsername(String username);
    public void updatePasswordAkun(Pegawai pegawai);
}
