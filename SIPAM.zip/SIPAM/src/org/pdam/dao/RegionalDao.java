package org.pdam.dao;

import org.pdam.model.Regional;

/**
 *
 * @author Melvandito
 */
public interface RegionalDao 
{
    public void saveRegional(Regional regional);
    public void getAllAnggotaRegionalByID(int idRegional);
}
