package org.pdam.dao;

import java.util.List;
import org.pdam.model.Akun;
import org.pdam.model.Pelanggan;

/**
 *
 * @author Melvandito
 */
public interface PelangganDao 
{
    public void savePelanggan(Pelanggan pelanggan);
    public List<Pelanggan> getPelangganByIDRegional(int idRegional);
    public String cekAkunPelanggan(String username, String password);
    public List<Pelanggan> getAllPelanggan();
    public Pelanggan getPelangganByUsername(String username);
    public Pelanggan getPelangganByIDPelanggan(int idPelanggan);
    public void updatePasswordAkun(Pelanggan pelanggan);
}
